%!PS-Adobe-3.0 EPSF-3.0
%%Creator: Mayura Draw, Version 4.1
%%Title: Cartoon.md
%%CreationDate: Mon Sep 16 17:46:16 2002
%%BoundingBox: 8 -61 576 772
%%DocumentFonts: ComicSansMS-Bold
%%+ ArialMT
%%Orientation: Portrait
%%EndComments
%%BeginProlog
%%BeginResource: procset MayuraDraw_ops
%%Version: 4.1
%%Copyright: (c) 1993-2001 Mayura Software
/PDXDict 100 dict def
PDXDict begin
% width height matrix proc key cache
% definepattern -\> font
/definepattern { %def
  7 dict begin
    /FontDict 9 dict def
    FontDict begin
      /cache exch def
      /key exch def
      /proc exch cvx def
      /mtx exch matrix invertmatrix def
      /height exch def
      /width exch def
      /ctm matrix currentmatrix def
      /ptm matrix identmatrix def
      /str
      (xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx)
      def
    end
    /FontBBox [ %def
      0 0 FontDict /width get
      FontDict /height get
    ] def
    /FontMatrix FontDict /mtx get def
    /Encoding StandardEncoding def
    /FontType 3 def
    /BuildChar { %def
      pop begin
      FontDict begin
        width 0 cache { %ifelse
          0 0 width height setcachedevice
        }{ %else
          setcharwidth
        } ifelse
        0 0 moveto width 0 lineto
        width height lineto 0 height lineto
        closepath clip newpath
        gsave proc grestore
      end end
    } def
    FontDict /key get currentdict definefont
  end
} bind def

% dict patternpath -
% dict matrix patternpath -
/patternpath { %def
  dup type /dicttype eq { %ifelse
    begin FontDict /ctm get setmatrix
  }{ %else
    exch begin FontDict /ctm get setmatrix
    concat
  } ifelse
  currentdict setfont
  FontDict begin
    FontMatrix concat
    width 0 dtransform
    round width div exch round width div exch
    0 height dtransform
    round height div exch
    round height div exch
    0 0 transform round exch round exch
    ptm astore setmatrix

    pathbbox
    height div ceiling height mul 4 1 roll
    width div ceiling width mul 4 1 roll
    height div floor height mul 4 1 roll
    width div floor width mul 4 1 roll

    2 index sub height div ceiling cvi exch
    3 index sub width div ceiling cvi exch
    4 2 roll moveto

    FontMatrix ptm invertmatrix pop
    { %repeat
      gsave
        ptm concat
        dup str length idiv { %repeat
          str show
        } repeat
        dup str length mod str exch
        0 exch getinterval show
      grestore
      0 height rmoveto
    } repeat
    pop
  end end
} bind def

% dict patternfill -
% dict matrix patternfill -
/patternfill { %def
  gsave
    eoclip patternpath
  grestore
  newpath
} bind def

/img { %def
  gsave
  /imgh exch def
  /imgw exch def
  concat
  imgw imgh 8
  [imgw 0 0 imgh neg 0 imgh]
  /colorstr 768 string def
  /colorimage where {
    pop
    { currentfile colorstr readhexstring pop }
    false 3 colorimage
  }{
    /graystr 256 string def
    {
      currentfile colorstr readhexstring pop
      length 3 idiv
      dup 1 sub 0 1 3 -1 roll
      {
        graystr exch
        colorstr 1 index 3 mul get 30 mul
        colorstr 2 index 3 mul 1 add get 59 mul
        colorstr 3 index 3 mul 2 add get 11 mul
        add add 100 idiv
        put
      } for
      graystr 0 3 -1 roll getinterval
    } image
  } ifelse
  grestore
} bind def

/arrowhead {
  gsave
    [] 0 setdash
    strokeC strokeM strokeY strokeK setcmykcolor
    2 copy moveto
    4 2 roll exch 4 -1 roll exch
    sub 3 1 roll sub
    exch atan rotate dup scale
    arrowtype
    dup 0 eq {
      -1 2 rlineto 7 -2 rlineto -7 -2 rlineto
      closepath fill
    } if
    dup 1 eq {
      0 3 rlineto 9 -3 rlineto -9 -3 rlineto
      closepath fill
    } if
    dup 2 eq {
      -6 -6 rmoveto 6 6 rlineto -6 6 rlineto
      -1.4142 -1.4142 rlineto 4.5858 -4.5858 rlineto
      -4.5858 -4.5858 rlineto closepath fill
    } if
    dup 3 eq {
      -6 0 rmoveto -1 2 rlineto 7 -2 rlineto -7 -2 rlineto
      closepath fill
    } if
    dup 4 eq {
      -9 0 rmoveto 0 3 rlineto 9 -3 rlineto -9 -3 rlineto
      closepath fill
    } if
    dup 5 eq {
      currentpoint newpath 3 0 360 arc
      closepath fill
    } if
    dup 6 eq {
      2.5 2.5 rmoveto 0 -5 rlineto -5 0 rlineto 0 5 rlineto
      closepath fill
    } if
    pop
  grestore
} bind def

/setcmykcolor where { %ifelse
  pop
}{ %else
  /setcmykcolor {
     /black exch def /yellow exch def
     /magenta exch def /cyan exch def
     cyan black add dup 1 gt { pop 1 } if 1 exch sub
     magenta black add dup 1 gt { pop 1 } if 1 exch sub
     yellow black add dup 1 gt { pop 1 } if 1 exch sub
     setrgbcolor
  } bind def
} ifelse

/RE { %def
  findfont begin
  currentdict dup length dict begin
    { %forall
      1 index /FID ne { def } { pop pop } ifelse
    } forall
    /FontName exch def dup length 0 ne { %if
      /Encoding Encoding 256 array copy def
      0 exch { %forall
        dup type /nametype eq { %ifelse
          Encoding 2 index 2 index put
          pop 1 add
        }{ %else
          exch pop
        } ifelse
      } forall
    } if pop
  currentdict dup end end
  /FontName get exch definefont pop
} bind def

/spacecount { %def
  0 exch
  ( ) { %loop
    search { %ifelse
      pop 3 -1 roll 1 add 3 1 roll
    }{ pop exit } ifelse
  } loop
} bind def

/WinAnsiEncoding [
  39/quotesingle 96/grave 130/quotesinglbase/florin/quotedblbase
  /ellipsis/dagger/daggerdbl/circumflex/perthousand
  /Scaron/guilsinglleft/OE 145/quoteleft/quoteright
  /quotedblleft/quotedblright/bullet/endash/emdash
  /tilde/trademark/scaron/guilsinglright/oe/dotlessi
  159/Ydieresis 164/currency 166/brokenbar 168/dieresis/copyright
  /ordfeminine 172/logicalnot 174/registered/macron/ring
  177/plusminus/twosuperior/threesuperior/acute/mu
  183/periodcentered/cedilla/onesuperior/ordmasculine
  188/onequarter/onehalf/threequarters 192/Agrave/Aacute
  /Acircumflex/Atilde/Adieresis/Aring/AE/Ccedilla
  /Egrave/Eacute/Ecircumflex/Edieresis/Igrave/Iacute
  /Icircumflex/Idieresis/Eth/Ntilde/Ograve/Oacute
  /Ocircumflex/Otilde/Odieresis/multiply/Oslash
  /Ugrave/Uacute/Ucircumflex/Udieresis/Yacute/Thorn
  /germandbls/agrave/aacute/acircumflex/atilde/adieresis
  /aring/ae/ccedilla/egrave/eacute/ecircumflex
  /edieresis/igrave/iacute/icircumflex/idieresis
  /eth/ntilde/ograve/oacute/ocircumflex/otilde
  /odieresis/divide/oslash/ugrave/uacute/ucircumflex
  /udieresis/yacute/thorn/ydieresis
] def

/SymbolEncoding [
  32/space/exclam/universal/numbersign/existential/percent
  /ampersand/suchthat/parenleft/parenright/asteriskmath/plus
  /comma/minus/period/slash/zero/one/two/three/four/five/six
  /seven/eight/nine/colon/semicolon/less/equal/greater/question
  /congruent/Alpha/Beta/Chi/Delta/Epsilon/Phi/Gamma/Eta/Iota
  /theta1/Kappa/Lambda/Mu/Nu/Omicron/Pi/Theta/Rho/Sigma/Tau
  /Upsilon/sigma1/Omega/Xi/Psi/Zeta/bracketleft/therefore
  /bracketright/perpendicular/underscore/radicalex/alpha
  /beta/chi/delta/epsilon/phi/gamma/eta/iota/phi1/kappa/lambda
  /mu/nu/omicron/pi/theta/rho/sigma/tau/upsilon/omega1/omega
  /xi/psi/zeta/braceleft/bar/braceright/similar
  161/Upsilon1/minute/lessequal/fraction/infinity/florin/club
  /diamond/heart/spade/arrowboth/arrowleft/arrowup/arrowright
  /arrowdown/degree/plusminus/second/greaterequal/multiply
  /proportional/partialdiff/bullet/divide/notequal/equivalence
  /approxequal/ellipsis/arrowvertex/arrowhorizex/carriagereturn
  /aleph/Ifraktur/Rfraktur/weierstrass/circlemultiply
  /circleplus/emptyset/intersection/union/propersuperset
  /reflexsuperset/notsubset/propersubset/reflexsubset/element
  /notelement/angle/gradient/registerserif/copyrightserif
  /trademarkserif/product/radical/dotmath/logicalnot/logicaland
  /logicalor/arrowdblboth/arrowdblleft/arrowdblup/arrowdblright
  /arrowdbldown/lozenge/angleleft/registersans/copyrightsans
  /trademarksans/summation/parenlefttp/parenleftex/parenleftbt
  /bracketlefttp/bracketleftex/bracketleftbt/bracelefttp
  /braceleftmid/braceleftbt/braceex
  241/angleright/integral/integraltp/integralex/integralbt
  /parenrighttp/parenrightex/parenrightbt/bracketrighttp
  /bracketrightex/bracketrightbt/bracerighttp/bracerightmid
  /bracerightbt
] def

/patarray [
/leftdiagonal /rightdiagonal /crossdiagonal /horizontal
/vertical /crosshatch /fishscale /wave /brick
] def
/arrowtype 0 def
/fillC 0 def /fillM 0 def /fillY 0 def /fillK 0 def
/strokeC 0 def /strokeM 0 def /strokeY 0 def /strokeK 1 def
/pattern -1 def
/mat matrix def
/mat2 matrix def
/nesting 0 def
/deferred /N def
/c /curveto load def
/c2 { pop pop c } bind def
/C /curveto load def
/C2 { pop pop C } bind def
/e { gsave concat 0 0 moveto } bind def
/F {
  nesting 0 eq { %ifelse
    pattern -1 eq { %ifelse
      fillC fillM fillY fillK setcmykcolor eofill
    }{ %else
      gsave fillC fillM fillY fillK setcmykcolor eofill grestore
      0 0 0 1 setcmykcolor
      patarray pattern get findfont patternfill
    } ifelse
  }{ %else
    /deferred /F def
  } ifelse
} bind def
/f { closepath F } bind def
/K { /strokeK exch def /strokeY exch def
     /strokeM exch def /strokeC exch def } bind def
/k { /fillK exch def /fillY exch def
     /fillM exch def /fillC exch def } bind def
/L /lineto load def
/L2 { pop pop L } bind def
/m /moveto load def
/m2 { pop pop m } bind def
/n /newpath load def
/N {
  nesting 0 eq { %ifelse
    newpath
  }{ %else
    /deferred /N def
  } ifelse
} def
/S {
  nesting 0 eq { %ifelse
    strokeC strokeM strokeY strokeK setcmykcolor stroke
  }{ %else
    /deferred /S def
  } ifelse
} bind def
/s { closepath S } bind def
/Tx { fillC fillM fillY fillK setcmykcolor show
      0 leading neg translate 0 0 moveto } bind def
/T { grestore } bind def
/TX { pop } bind def
/Ts { pop } bind def
/tal { pop } bind def
/tld { pop } bind def
/tbx { pop exch pop sub /jwidth exch def } def
/tpt { %def
  fillC fillM fillY fillK setcmykcolor
  moveto show
} bind def
/tpj { %def
  fillC fillM fillY fillK setcmykcolor
  moveto
  dup stringwidth pop
  3 -1 roll
  exch sub
  1 index spacecount
  dup 0 eq { %ifelse
    pop pop show
  }{ %else
    div 0 8#040 4 -1 roll widthshow
  } ifelse
} bind def
/u {} def
/U {} def
/*u { /nesting nesting 1 add def } def
/*U {
  /nesting nesting 1 sub def
  nesting 0 eq {
    deferred cvx exec
  } if
} def
/w /setlinewidth load def
/d /setdash load def
/B {
  nesting 0 eq { %ifelse
    gsave F grestore S
  }{ %else
    /deferred /B def
  } ifelse
} bind def
/b { closepath B } bind def
/z { /align exch def pop /leading exch def exch findfont
     exch scalefont setfont } bind def
/tfn { exch findfont
     exch scalefont setfont } bind def
/Pat { /pattern exch def } bind def
/cm { 6 array astore concat } bind def
/q { mat2 currentmatrix pop } bind def
/Q { mat2 setmatrix } bind def
/Ah {
  pop /arrowtype exch def
  currentlinewidth 5 1 roll arrowhead
} bind def
/Arc {
  mat currentmatrix pop
    translate scale 0 0 1 5 -2 roll arc
  mat setmatrix
} bind def
/Arc2 { pop pop Arc } bind def
/Bx {
  mat currentmatrix pop
    concat /y1 exch def /x1 exch def /y2 exch def /x2 exch def
    x1 y1 moveto x1 y2 lineto x2 y2 lineto x2 y1 lineto
  mat setmatrix
} bind def
/Rr {
  mat currentmatrix pop
    concat /yrad exch def /xrad exch def
    2 copy gt { exch } if /x2 exch def /x1 exch def
    2 copy gt { exch } if /y2 exch def /y1 exch def
    x1 xrad add y2 moveto
    matrix currentmatrix x1 xrad add y2 yrad sub translate xrad yrad scale
    0 0 1 90 -180 arc setmatrix
    matrix currentmatrix x1 xrad add y1 yrad add translate xrad yrad scale
    0 0 1 180 270 arc setmatrix
    matrix currentmatrix x2 xrad sub y1 yrad add translate xrad yrad scale
    0 0 1 270 0 arc setmatrix
    matrix currentmatrix x2 xrad sub y2 yrad sub translate xrad yrad scale
    0 0 1 0 90 arc setmatrix
    closepath
  mat setmatrix
} bind def
/Ov {
  mat currentmatrix pop
    concat translate scale 1 0 moveto 0 0 1 0 360 arc closepath
  mat setmatrix
} bind def
end
%%EndResource
%%EndProlog
%%BeginSetup
%PDX g 3 3 0 0
%%IncludeFont: ComicSansMS-Bold
%%IncludeFont: ArialMT
PDXDict begin
%%EndSetup
%%Page: 1 1
%%BeginPageSetup
/_PDX_savepage save def

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/rightdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/leftdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  2 setlinewidth stroke
} bind
/horizontal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/vertical true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/crosshatch true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 30 7.5 lineto
  0 22.5 moveto 30 22.5 lineto
  7.5 0 moveto 7.5 7.5 lineto
  7.5 22.5 moveto 7.5 30 lineto
  22.5 7.5 moveto 22.5 22.5 lineto
  1 setlinewidth stroke
} bind
/brick true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  0.5 setlinewidth stroke
} bind
/crossdiagonal true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  1 setlinecap
  0 7.5 moveto 0 15 7.5 270 360 arc
  7.5 15 moveto 15 15 7.5 180 270 arc
  0 7.5 moveto 7.5 7.5 7.5 180 360 arc
  0.5 setlinewidth stroke
} bind
/fishscale true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  1 setlinecap 0.5 setlinewidth
  7.5 0 10.6 135 45 arcn
  22.5 15 10.6 225 315 arc
  stroke
  7.5 15 10.6 135 45 arcn
  22.5 30 10.6 225 315 arc
  stroke
} bind
/wave true definepattern pop

WinAnsiEncoding /_ComicSansMS-Bold /ComicSansMS-Bold RE
WinAnsiEncoding /_ArialMT /ArialMT RE

newpath 2 setlinecap 0 setlinejoin 2 setmiterlimit
[] 0 setdash
8 -61 moveto 8 772 lineto 576 772 lineto 576 -61 lineto closepath clip
newpath
%%EndPageSetup
0 0.8 0.6 0 k
0 0.8 0.6 0 K
2 w
q
1 0 0 1 -20.75 13.21 cm
66.8 725.6 m
207.6 637.6 L
335.6 749.6 L
586.8 255.2 L
457.2 256.8 L
311.6 60 L
66.8 725.6 L
Q
b
0.6 0.2 0.6 0 k
0.6 0.2 0.6 0 K
1 w
q
1 0 0 1 -11.15 -26.79 cm
545.2 525.6 m
110 287.2 L
252.4 136.8 L
522.8 434.4 L
545.2 525.6 L
Q
b
q
1 0 0 1 -38.35 6.805 cm
71.6 412 m
426.8 756 L
586.8 570.4 L
116.4 391.2 L
71.6 412 L
Q
b
0 0 0.6 0 k
1 1 1 0 K
2 w
q
1 0 0 1 -20.75 13.21 cm
137.587 418.488 m
159.288 452.18 194.979 482.447 219.82 492.44 C
219.527 497.051 213.354 500.433 208.685 500.149 C
175.278 485.587 146.153 457.605 134.161 433.906 C
133.019 429.623 133.416 419.823 137.587 418.488 C
Q
b
0.4 0.2 0 0 k
q
1 0 0 1 -20.75 14.07 cm
134.359 434.554 m
111.864 464.836 94.56 554.382 106.673 564.332 c
123.976 576.012 167.566 557.764 168.101 549.624 c
168.928 537.018 148.921 538.491 128.951 537.593 C
159.22 539.057 146.888 537.773 159.691 539.837 C
165.748 532.051 180.646 515.882 206.601 499.443 C
168.966 480.409 149.932 456.616 134.359 434.554 C
Q
b
0 0.084 0.12 0 k
3 w
q
1 0 0 1 -20.75 13.21 cm
168.448 393.136 m
153.234 413.53 141.154 393.341 158.736 385.806 c
162.449 384.215 169.664 382.093 174.015 383.048 C
180.867 374.119 211.014 370.108 225.622 377.215 c
246.452 387.348 254.333 408.741 253.77 417.467 c
253.155 427.005 248.422 429.289 242.9 433.599 C
236.831 442.399 241.253 471.037 227.038 476.328 C
203.667 477.141 168.763 459.689 156.147 435.541 C
154.97 421.689 152.263 415.148 168.448 393.136 C
Q
b
0 0.4 0.6 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
168.763 392.696 m
155.533 412.119 175.237 425.63 161.163 437.452 C
164.204 439.954 166.911 440.077 170.733 439.704 C
169.248 441.923 167.28 442.784 164.259 443.644 C
170.97 449.058 188.931 447.458 196.63 444.489 C
194.959 449.304 191.76 452.01 183.681 453.215 C
191.923 458.24 203.609 457.502 210.985 455.748 C
210.375 459.962 203.732 461.93 199.163 463.63 C
207.669 465.375 215.788 463.899 221.4 459.689 C
222.062 462.914 220.832 464.637 219.43 466.444 C
228.09 464.883 230.919 460.823 232.659 454.059 C
244.451 461.069 244.082 483.335 229 482.489 C
231.042 486.534 238.054 487.641 243.959 486.288 C
240.023 496.867 224.817 494.233 219.993 492.341 C
198.037 483.052 163.696 458.844 137.8 418.311 C
135.929 408.423 142.938 396.59 151.03 391.852 C
147.652 394.948 152.156 412.963 168.763 392.696 C
Q
b
0 0 0 0 k
q
1 0 0 1 -20.75 13.21 cm
218.596 412.424 m
223.807 413.6 225.825 415.113 229.019 416.122 C
230.027 413.264 229.691 409.398 228.346 406.708 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
229.355 415.786 m
233.557 416.626 240.785 421.837 242.13 425.367 C
238.432 444.026 227.338 453.272 221.454 449.742 C
213.722 444.194 216.243 426.712 229.355 415.786 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
190.356 396.959 m
196.071 397.463 203.804 400.993 207.166 404.859 C
203.468 425.031 188.507 438.143 180.606 432.764 C
172.369 426.208 176.404 407.717 190.356 396.959 C
Q
b
1 1 1 0 k
1 w
8.69117 11.4076 222.295 447.738 [0.9753 0.2207 -0.2207 0.9753 51.45 -52.4] Ov
b
0 0 0 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
171.865 427.721 m
171.529 435.117 175.059 440.16 180.942 440.832 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
214.31 454.268 m
216.169 459.691 223.45 459.381 228.408 455.818 c
Q
S
1 1 1 0 k
1 w
7.36955 10.46 222.295 447.738 [0.9753 0.2207 -0.2207 0.9753 89.65 -35.06] Ov
b
0 0 0 0 k
3.45979 5.52293 222.295 447.738 [0.9753 0.2207 -0.2207 0.9753 90.65 -32.23] Ov
b
4.08977 6.318 222.295 447.738 [0.9753 0.2207 -0.2207 0.9753 52.6 -49.23] Ov
b
1 1 1 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
228.772 396.068 m
220.964 389.461 219.91 387.384 206.095 391.388 C
208.356 384.235 215.219 378.963 221.311 380.777 c
225.707 382.085 225.008 391.401 226.772 394.068 C
227.272 394.568 226.424 393.726 228.772 396.068 C
Q
b
0 0 0 0 k
q
1 0 0 1 -20.92 11.79 cm
204.606 389.402 m
204.356 391.652 205.522 394.068 207.939 395.568 c
Q
S
0 0.6 0.6 0 k
1 w
q
1 0 0 1 -20.75 13.21 cm
208.189 387.568 m
214.272 388.152 220.106 386.235 223.606 383.318 C
222.301 377.73 210.57 380.91 208.189 387.568 C
Q
b
0 0 0 0 k
q
1 0 0 1 -20.75 13.21 cm
155.066 392.169 m
151.65 398.147 157.201 400.709 163.605 392.81 C
159.335 392.596 160.403 386.832 167.448 387.899 c
Q
S
0.4 0.2 0 0 k
3 w
q
1 0 0 1 -20.75 13.21 cm
89.1185 333.695 m
98.4222 327.647 106.796 318.344 113.773 305.784 C
130.985 325.787 152.849 340.207 170.526 344.394 C
168.2 313.227 172.852 264.382 193.785 222.516 C
237.513 227.633 244.956 268.104 268.215 274.151 C
248.677 290.433 222.743 320.049 219.952 354.473 C
239.955 347.96 296.126 363.001 313.803 390.913 C
313.803 400.216 306.36 415.102 291.939 423.01 C
278.914 400.681 240.304 372.77 216.579 373.236 C
212.215 368.802 210.997 356.954 202.624 351.372 C
193.32 355.559 185.087 361.262 178.616 365.742 C
149.888 369.642 102.609 356.024 89.1185 333.695 C
Q
b
0 0.084 0.12 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
202.637 224.178 m
205.544 218.33 207.161 216.228 211.111 210.163 C
218.97 205.714 230.616 212.345 229.037 220.593 C
227.057 225.448 225.925 229.006 223.496 233.63 C
218.646 229.492 207.97 225.286 202.637 224.178 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
242.163 251.751 m
246.779 249.078 248.966 248.107 254.311 244.462 C
261.6 243.247 270.347 253.695 267.674 257.825 C
263.058 261.713 260.628 264.142 256.741 267.544 C
250.181 261.47 247.508 257.825 242.163 251.751 C
Q
b
0.4 0.2 0 0 k
q
1 0 0 1 -20.75 13.21 cm
258.613 238.72 m
260.96 231.093 265.123 226.134 270.933 228.356 c
277.582 230.898 281.488 237.379 283.815 241.828 C
287.921 247.304 308.244 253.612 295.769 275.093 C
291.662 279.396 291.467 267.662 283.058 263.947 c
280.275 262.717 273.169 263.352 270.738 260.231 C
277.387 257.689 274.22 247.873 270.738 244.391 c
267.218 240.871 262.524 238.329 258.613 238.72 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
215.987 201.591 m
215.699 191.819 218.757 185.908 218.573 180.898 c
218.477 178.284 213.864 169.874 215.987 167.964 c
220.781 163.649 235.243 171.701 239.267 178.598 c
242.47 184.09 241.853 193.256 240.991 199.292 C
248.464 216.824 239.006 219.606 234.956 219.698 C
237.542 211.938 232.757 207.818 229.207 204.753 c
226.008 201.99 220.01 200.729 215.987 201.591 C
Q
b
0 0.084 0.12 0 k
q
1 0 0 1 -20.75 13.21 cm
89.4089 333.416 m
83.2548 330.041 79.0859 322.299 77.8948 320.91 c
74.8678 317.378 58.837 306.418 62.4104 304.036 c
72.2229 297.494 88.2854 319.521 92.3867 316.939 c
97.7467 313.564 85.9193 301.532 93.9748 298.08 c
96.7541 296.889 99.2867 306.37 101.717 310.19 c
103.107 312.373 105.312 317.04 104.298 320.116 C
101.519 323.49 94.7689 329.644 89.4089 333.416 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
76.3067 306.021 m
75.4035 304.895 67.5719 302.844 72.7333 300.661 c
79.7693 297.684 86.8282 308.8 89.4089 316.344 C
85.4385 313.167 80.0785 308.8 76.3067 306.021 C
Q
b
0 0 0.2 0 k
0 0 0.2 0 K
1 w
q
1 0 0 1 -20.21 13.38 cm
313.99 212.255 m
504.664 315.821 440.664 562.221 273.974 527.287 C
278.264 523.891 279.157 524.606 288.179 516.151 C
279.157 517.099 275.94 516.92 272.365 516.563 C
274.689 512.988 275.94 512.095 279.853 507.825 C
275.761 508.699 266.878 508.979 261.641 509.235 C
261.641 504.23 262.178 498.511 263.201 492.839 C
259.318 495.83 257.53 497.617 254.876 499.499 C
253.062 496.545 251.632 491.719 249.88 487.843 C
248.058 491.54 247.478 495.763 246.076 502.42 C
240.821 500.317 238.763 498.511 235.546 497.975 C
237.512 501.549 237.334 503.873 239.056 508.658 C
233.401 507.984 228.218 506.196 222.499 504.945 C
226.224 508.556 227.861 510.843 230.73 514.486 C
226.252 517.278 221.605 518.529 217.409 521.979 C
224.465 523.712 226.431 524.606 231.563 526.142 C
227.503 529.432 223.035 532.828 219.907 536.966 C
224.107 536.76 230.061 535.416 234.474 534.615 C
233.58 540.156 233.401 542.837 233.228 547.79 C
236.619 542.837 239.726 541.502 243.768 539.083 C
245.555 544.088 246.806 548.199 249.047 553.618 C
250.56 549.271 251.903 543.76 253.956 538.547 C
256.371 543.223 259.497 545.875 261.536 549.455 C
262.714 545.875 262.767 540.425 264.144 537.296 C
265.984 540.961 271.114 544.267 273.193 546.957 C
273.259 543.552 271.829 541.407 271.472 538.19 C
498.264 600.621 503.064 269.421 313.99 212.255 C
Q
b
0.4 0.6 0.6 0 k
1 1 1 0 K
q
1 0 0 1 -22.35 9.605 cm
253.21 520.083 m
281.157 484.761 307.163 451.769 333.945 419.941 C
337.279 419.658 340.32 422.358 340.544 425.763 C
313.373 461.861 284.65 488.643 256.316 522.412 C
254.868 522.565 253.394 521.554 253.21 520.083 C
Q
b
0 0.084 0.12 0 k
0 0.084 0.12 0 K
q
1 0 0 1 -22.35 9.605 cm
296.533 425.067 m
300.267 422.4 307.733 415.467 311.2 410.667 C
312.8 413.067 314.356 415.985 316 416.533 c
319.2 417.6 325.6 424.8 324.533 429.6 C
326.418 432.195 334.375 432.95 336.042 441.95 C
336.542 443.867 333.225 449.717 328.958 445.45 C
333.225 456.65 319.992 454.75 318.125 449.95 C
325.708 459.533 317.6 465.867 312.8 462.133 c
310.962 460.704 308.542 458.867 307.208 457.2 C
294.625 459.117 293.6 436 298.4 427.467 C
298.072 426.823 296.459 426.181 296.533 425.067 C
Q
b
u
0 0 0 0 k
1 1 1 0 K
2 w
q
1 0 0 1 -22.35 9.605 cm
296.533 425.067 m
297.792 426.617 296.792 425.45 298.542 427.7 C
295.875 430.9 292 442.667 299.733 454.4 c
305.248 462.767 319.428 451.363 318.133 446.4 c
316.533 440.267 312.267 442.4 303.467 444.8 C
312.8 443.2 310.667 429.867 307.733 424.8 c
Q
S
1 1 1 0 k
q
1 0 0 1 -22.35 9.605 cm
307.292 457.283 m
319.061 471.586 325.846 457.681 317.458 449.617 c
Q
S
q
1 0 0 1 -22.35 9.605 cm
317.838 449.894 m
327.2 459.467 335.692 449.77 324.8 439.467 c
314.933 430.133 308.367 438.231 311.042 442.533 c
Q
S
q
1 0 0 1 -16.15 2.735 cm
323.592 453.067 m
329.192 456.267 334.6 447.667 324.2 440.2 c
314.233 433.044 308.2 438.067 310.333 441.8 c
Q
S
U
q
1 0 0 1 -22.35 9.605 cm
324.542 430.117 m
325.302 421.416 318.292 417.7 315.792 416.367 C
314.542 415.367 312.875 413.367 311.125 410.45 c
Q
S
0 0.084 0.12 0 k
1 w
q
1 0 0 1 -20.75 13.21 cm
183.428 377.025 m
191.227 373.541 204.335 373.375 209.313 373.541 C
209.479 367.07 207.321 359.105 202.676 353.796 C
196.868 357.28 186.249 368.895 183.428 377.025 C
Q
b
0 0 0.6 0 k
q
1 0 0 1 -20.75 9.258 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
0 0 0.6 0 K
q
0.7216 -0.2988 0.3453 0.6245 -63.31 339.2 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.7216 0.2988 0.3453 -0.6245 1.169 733.2 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
-0.7216 -0.2988 -0.3453 0.6245 794.1 239.9 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.7216 -0.2988 0.3453 0.6245 32.81 145.7 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.7216 -0.2988 0.3453 0.6245 90.85 132.5 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
1 1 1 0 K
q
0.8582 0.2146 -0.2239 0.8955 22.66 -37.16 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.8385 -0.2951 0.2724 0.774 -200.4 182.4 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.7253 0 0 0.7515 -64.35 129.7 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
2 w
q
1 0 0 1 -20.75 13.21 cm
377.467 575.947 m
371.719 566.305 362.723 539.5 377.04 523.893 c
396.081 503.137 407.701 534.903 387.511 535.902 C
385.378 541.875 384.242 549.256 385.948 557.362 C
391.364 554.512 399.202 554.797 404.347 556.747 C
410.32 554.187 412.099 547.138 412.099 543.298 C
398.551 528.43 420.695 508.715 429.093 534.56 c
432.275 544.352 427.387 556.747 420.133 565.707 C
430.373 571.68 431.227 583.2 436.347 590.453 C
441.893 585.76 448.063 586.421 451.73 588.754 C
452.98 583.004 452.987 573.813 462.373 573.813 c
475.628 573.813 470.35 617.927 456.827 624.587 c
453.785 626.085 450 622.453 447.013 618.613 C
443.173 628 436.773 634.827 431.653 636.107 C
437.627 649.76 444.453 677.067 415.013 689.013 c
392.509 698.145 373.707 677.037 382.16 672.373 c
394.533 665.547 391.547 682.613 411.6 675.36 c
431.199 668.271 421.84 646.773 414.16 636.107 C
410.41 635.828 404.719 632.815 403.714 629.132 c
399.66 614.268 382.836 590.589 377.467 575.947 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
363.83 632.797 m
367.587 633.823 375.28 624.29 379.358 620.121 C
382.521 620.696 382.098 625.624 383.068 628.323 C
383.994 624.676 385.178 622.78 387.99 621.164 C
389.918 623.017 390.155 626.098 392.016 627.876 C
392.998 625.387 392.287 625.387 392.911 622.954 C
397.026 629.178 402.713 638.419 405.438 638.166 C
410.223 635.859 411.858 619.099 420.203 603.716 C
425.101 602.841 425.868 603.455 429.151 602.373 C
425.868 598.547 424.948 598.7 422.887 594.767 C
426.635 593.946 427.862 594.099 430.046 592.53 C
426.942 590.571 425.101 591.032 422.887 588.056 C
425.101 586.737 426.788 586.277 427.809 584.03 C
424.641 583.516 423.414 583.823 421.098 582.687 C
412.903 567.094 382.572 560.933 365.172 576.424 C
362.679 577.381 360.378 576.154 355.776 576.424 C
357.311 579.682 357.617 579.989 358.908 582.687 C
356.85 583.67 355.47 583.67 353.092 584.924 C
355.163 585.97 356.084 586.584 359.356 587.609 C
357.464 592.412 353.936 593.792 351.302 597.452 C
354.09 597.933 357.311 597.013 361.145 597.899 C
361.576 610.718 359.532 628.705 363.83 632.797 C
Q
b
0 0 0 0 k
8.67604 10.8451 392.126 606.522 [0.9453 -0.3261 0.3261 0.9453 -187.2 169.1] Ov
b
8.67604 10.8451 392.126 606.522 [-0.7848 -0.6197 -0.6197 0.7848 1040 376.5] Ov
b
1 1 1 0 k
1 w
4.98872 5.4225 376.789 594.406 [1 0 0 1 -17.07 10.9] Ov
b
4.98872 5.4225 376.789 594.406 [1 0 0 1 1.879 15.75] Ov
b
0 0.2 0 0 k
q
1 0 0 1 -21.08 13.46 cm
386.911 587.964 m
387.236 589.858 394.801 591.584 395.96 589.958 c
396.77 588.823 395.168 587.188 392.586 584.437 C
388.418 586.021 386.678 586.599 386.911 587.964 c
Q
b
1 1 1 0 k
q
1 0 0 1 -20.75 13.21 cm
392.752 582.938 m
394.168 576.604 384.168 576.938 384.168 572.771 c
384.168 565.438 392.502 567.688 396.418 568.104 c
399.956 568.481 408.502 569.938 405.918 575.854 c
404.066 580.096 395.168 576.438 392.752 582.938 C
Q
b
0 0.8 0.6 0 k
q
1 0 0 1 -20.75 13.21 cm
386.585 568.271 m
385.502 569.604 391.168 575.604 395.252 572.271 C
398.002 576.188 404.918 572.938 404.918 570.854 C
400.252 567.938 391.335 566.854 386.585 568.271 C
Q
b
0.2 0.2 0.2 0 k
q
1 0 0 1 -20.75 13.21 cm
365.255 629.319 m
364.437 625.231 363.824 619.712 364.233 614.602 C
367.912 617.259 370.978 618.281 375.475 619.303 C
372.409 623.187 368.73 626.661 365.255 629.319 C
Q
b
q
0.8517 -0.524 0.524 0.8517 -256.4 303.8 cm
365.255 629.319 m
364.437 625.231 363.824 619.712 364.233 614.602 C
367.912 617.259 370.978 618.281 375.475 619.303 C
372.409 623.187 368.73 626.661 365.255 629.319 C
Q
b
0 0 0.6 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
428.593 611.579 m
429.368 583.678 452.309 578.388 460.834 600.883 c
Q
S
1 w
q
1 0 0 1 -22 13.29 cm
465.794 574.513 m
465.71 574.486 465.671 574.486 465.639 574.513 c
463.995 575.892 463.646 577.869 464.244 582.418 c
Q
S
q
1 0 0 1 -27 13.04 cm
465.794 574.513 m
465.71 574.486 465.671 574.486 465.639 574.513 c
463.995 575.892 463.646 577.869 464.244 582.418 c
Q
S
0 0 0 0 k
q
1 0 0 1 -20.75 13.21 cm
412.944 523.274 m
417.2 523.633 420.384 525.849 420.938 529.31 c
Q
S
q
1 0 0 1 -24.26 17.17 cm
412.944 523.274 m
417.2 523.633 420.384 525.849 420.938 529.31 c
Q
S
q
-1 0 0 1 785.7 7.851 cm
412.944 523.274 m
417.2 523.633 420.384 525.849 420.938 529.31 c
Q
S
q
-1 0 0 1 789.1 11.82 cm
412.944 523.274 m
417.2 523.633 420.384 525.849 420.938 529.31 c
Q
S
2 w
q
1 0 0 1 -21 13.29 cm
420.437 565.628 m
418.585 567.909 416.908 569.508 415.34 570.505 c
Q
S
1 1 1 0 k
1 w
q
1 0 0 1 -20.75 13.21 cm
477.133 571.87 m
480.144 580.524 479.391 589.932 476.757 600.092 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
483.154 569.988 m
485.412 576.009 485.412 584.287 485.036 591.061 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
427.086 518.812 m
431.225 521.07 434.236 526.338 436.87 533.487 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
432.73 515.802 m
436.493 518.436 439.127 522.575 440.633 527.843 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
119.81 300.865 m
126.69 309.019 135.354 315.135 145.037 319.976 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
127.455 300.101 m
129.748 303.668 135.609 307.745 141.47 310.548 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
295.545 364.895 m
303.329 368.261 308.799 373.52 314.268 380.673 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
302.698 360.898 m
308.588 363.001 312.796 366.788 316.793 371.627 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
272.074 220.948 m
278.889 222.133 284.815 227.763 287.778 234.874 c
Q
S
q
1 0 0 1 -21.94 14.69 cm
277.704 213.541 m
283.63 215.318 287.778 219.467 290.741 225.393 c
Q
S
q
1 0 0 1 -20.75 13.21 cm
236.222 166.726 m
243.037 169.393 246.889 175.911 248.074 183.911 c
Q
S
q
1 0 0 1 -21.64 13.8 cm
244.519 164.059 m
248.963 166.43 251.926 170.578 253.407 175.615 c
Q
S
0 0 0.6 0 k
2 w
q
1 0 0 1 -20.75 13.21 cm
287.356 415.97 m
290.018 413.75 291.607 412.956 293.4 410.681 C
289.885 406.598 286.441 400.637 284.837 397.333 C
287.369 399.445 292.137 402.889 298.185 405.644 C
300.482 403.684 302.761 400.828 303.661 398.253 C
299.318 393.675 295.713 391.233 293.904 386.504 C
297.833 388.716 302.071 391.1 306.575 392.557 C
308.097 389.879 308.164 386.465 308.763 384.237 C
310.946 386.465 312.005 388.319 314.052 391.037 C
314.389 401.432 301.409 418.386 291.889 423.022 C
290.283 420.373 289.091 418.519 287.356 415.97 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
89.2104 333.541 m
98.2598 327.447 109.525 315.812 113.588 305.47 C
115.62 308.055 118.176 311.086 121.261 313.638 C
120.595 316.9 118.164 319.545 116.581 321.509 C
119.027 325.338 124.997 330.285 126.792 332.252 C
124.665 332.146 115.943 328.742 111.557 326.893 C
109.774 328.848 107.221 331.827 104.562 333.635 C
107.266 337.87 112.515 342.262 115.198 344.271 C
111.558 344.071 103.498 340.336 99.7372 337.789 C
98.2866 339.059 97.4357 339.91 95.3048 341.298 C
93.0887 339.266 91.2419 336.681 89.2104 333.541 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
188.622 233.304 m
188.296 229.393 189.926 224.504 193.511 222.548 C
235.556 226.459 245.333 265.57 268.148 274.37 C
268.316 277.559 264.177 280.349 260.978 280.563 C
240.444 274.696 217.956 228.415 188.622 233.304 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
183.076 376.966 m
187.982 368.243 192.344 360.883 202.566 353.659 C
207.2 358.293 209.79 367.289 209.108 373.559 C
223.556 374.785 209.517 354.886 202.566 350.252 C
192.207 355.431 182.433 361.096 176.397 368.243 C
174.489 370.969 176.67 377.375 183.076 376.966 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
157.544 365.742 m
172.871 365.998 172.353 346.051 169.033 337.111 C
180.528 339.921 182.549 360.765 175.93 368.02 c
172.353 374.406 158.055 374.683 157.544 365.742 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
213.62 373.597 m
218.401 370.367 219.952 353.569 221.115 345.299 C
224.795 345.295 233.123 364.121 227.317 372.305 C
224.46 376.333 218.272 375.148 213.62 373.597 C
Q
b
0.4 0 0 0 k
q
1 0 0 1 -20.75 13.21 cm
209.818 211.695 m
206.342 204.185 217.987 196.65 229.517 204.87 c
239.719 212.142 236.481 225.304 227.773 223.964 C
231.458 219.254 228.501 213.931 224.781 211.096 c
220.564 207.883 212.621 206.924 209.818 211.695 C
Q
b
q
1 0 0 1 -20.75 13.21 cm
252.433 245.414 m
250.502 236.985 261.652 236.897 268.94 243.131 c
275.882 249.069 277.545 263.94 265.244 260.012 C
271.398 255.95 266.863 251.321 264.374 248.487 c
261.666 245.403 256.121 241.814 252.433 245.414 C
Q
b
0 0 0.6 0 k
0 0 0.6 0 K
1 w
q
0.4811 -0.2158 0.2302 0.451 3.529 301.6 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.4811 -0.2158 0.2302 0.451 43.26 348.5 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
0 0 0.8 0 k
q
0.4811 -0.2158 0.2302 0.451 203.7 268.6 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
0 0 0.6 0 k
q
-0.4811 -0.2158 -0.2302 0.451 575.3 387.6 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
-0.4811 -0.2158 -0.2302 0.451 564.1 333.6 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
-0.4811 -0.2158 -0.2302 0.451 605 249.4 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.4811 -0.2158 0.2302 0.451 195 373.9 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
0.4811 -0.2158 0.2302 0.451 137.4 166.3 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
q
-0.4811 -0.2158 -0.2302 0.451 494.7 406.1 cm
235.639 520.124 m
244.628 525.606 L
238.489 536.788 L
249.671 529.991 L
257.126 537.446 L
254.933 527.36 L
265.019 521.44 L
252.96 521.879 L
250.987 507.627 L
246.821 519.686 L
235.639 520.124 L
Q
b
[1 0 0 1 -131.3 47.06] e
697.792 29.088 492.4 148 tbx
1 tal
52 tld
1 1 1 0 k
/_ComicSansMS-Bold 48 tfn
(Little) 532.552 95.104 tpt
( ) TX
(Wizard) 511.552 43.104 tpt
T
[1 0 0 1 -134 50.53] e
697.792 29.088 492.4 148 tbx
1 tal
52 tld
0.6 0.4 0 0 k
/_ComicSansMS-Bold 48 tfn
(Little) 532.552 95.104 tpt
(\r) TX
(Wizard) 511.552 43.104 tpt
T
[1 0 0 1 0 0] e
18.3144 14.9345 18.3144 14.9345 tbx
0 tal
52 tld
1 1 1 0 k
/_ComicSansMS-Bold 48 tfn
() 18.3144 -37.9615 tpt
T
[1 0 0 1 128.4 3.773] e
33.4061 16.821 33.4061 16.821 tbx
0 tal
15 tld
/_ArialMT 14 tfn
(Created using Mayura Draw by Herb Montes.) 33.4061 4.151 tpt
T
%%PageTrailer
_PDX_savepage restore
%%Trailer
end
showpage
%%EOF
