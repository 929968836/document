%!PS-Adobe-3.0 EPSF-3.0
%%Creator: Mayura Draw, Version 2.1
%%Title: Flier.pdx
%%CreationDate: Sat Dec 13 13:27:37 1997
%%BoundingBox: 15 13 596 786
%%DocumentFonts: ComicSansMS
%%+ ArialMT
%%Orientation: Portrait
%%EndComments
%%BeginProlog
%%BeginResource: procset MayuraDraw_ops
%%Version: 2.1
%%Copyright: (c) 1993-97 Mayura Software
/PDXDict 100 dict def
PDXDict begin
% width height matrix proc key cache
% definepattern -\> font
/definepattern { %def
  7 dict begin
    /FontDict 9 dict def
    FontDict begin
      /cache exch def
      /key exch def
      /proc exch cvx def
      /mtx exch matrix invertmatrix def
      /height exch def
      /width exch def
      /ctm matrix currentmatrix def
      /ptm matrix identmatrix def
      /str
      (12345678901234567890123456789012)
      def
    end
    /FontBBox [ %def
      0 0 FontDict /width get
      FontDict /height get
    ] def
    /FontMatrix FontDict /mtx get def
    /Encoding StandardEncoding def
    /FontType 3 def
    /BuildChar { %def
      pop begin
      FontDict begin
        width 0 cache { %ifelse
          0 0 width height setcachedevice
        }{ %else
          setcharwidth
        } ifelse
        0 0 moveto width 0 lineto
        width height lineto 0 height lineto
        closepath clip newpath
        gsave proc grestore
      end end
    } def
    FontDict /key get currentdict definefont
  end
} bind def

% dict patternpath -
% dict matrix patternpath -
/patternpath { %def
  dup type /dicttype eq { %ifelse
    begin FontDict /ctm get setmatrix
  }{ %else
    exch begin FontDict /ctm get setmatrix
    concat
  } ifelse
  currentdict setfont
  FontDict begin
    FontMatrix concat
    width 0 dtransform
    round width div exch round width div exch
    0 height dtransform
    round height div exch
    round height div exch
    0 0 transform round exch round exch
    ptm astore setmatrix

    pathbbox
    height div ceiling height mul 4 1 roll
    width div ceiling width mul 4 1 roll
    height div floor height mul 4 1 roll
    width div floor width mul 4 1 roll

    2 index sub height div ceiling cvi exch
    3 index sub width div ceiling cvi exch
    4 2 roll moveto

    FontMatrix ptm invertmatrix pop
    { %repeat
      gsave
        ptm concat
        dup str length idiv { %repeat
          str show
        } repeat
        dup str length mod str exch
        0 exch getinterval show
      grestore
      0 height rmoveto
    } repeat
    pop
  end end
} bind def

% dict patternfill -
% dict matrix patternfill -
/patternfill { %def
  gsave
    clip patternpath
  grestore
  newpath
} bind def

/img { %def
  gsave
  /imgh exch def
  /imgw exch def
  concat
  imgw imgh 8
  [imgw 0 0 imgh neg 0 imgh]
  /colorstr 768 string def
  /colorimage where {
    pop
    { currentfile colorstr readhexstring pop }
    false 3 colorimage
  }{
    /graystr 256 string def
    {
      currentfile colorstr readhexstring pop
      length 3 idiv
      dup 1 sub 0 1 3 -1 roll
      {
        graystr exch
        colorstr 1 index 3 mul get 30 mul
        colorstr 2 index 3 mul 1 add get 59 mul
        colorstr 3 index 3 mul 2 add get 11 mul
        add add 100 idiv
        put
      } for
      graystr 0 3 -1 roll getinterval
    } image
  } ifelse
  grestore
} bind def

/arrowhead {
  gsave
    [] 0 setdash
    strokeC strokeM strokeY strokeK setcmykcolor
    2 copy moveto
    4 2 roll exch 4 -1 roll exch
    sub 3 1 roll sub
    exch atan rotate dup scale
    arrowtype
    dup 0 eq {
      -1 2 rlineto 7 -2 rlineto -7 -2 rlineto
      closepath fill
    } if
    dup 1 eq {
      0 3 rlineto 9 -3 rlineto -9 -3 rlineto
      closepath fill
    } if
    dup 2 eq {
      currentpoint -6 -6 rmoveto lineto -6 6 rlineto
      2 setlinewidth stroke
    } if
    pop
  grestore
} bind def

/setcmykcolor where { %ifelse
  pop
}{ %else
  /setcmykcolor {
     /black exch def /yellow exch def
     /magenta exch def /cyan exch def
     cyan black add dup 1 gt { pop 1 } if 1 exch sub
     magenta black add dup 1 gt { pop 1 } if 1 exch sub
     yellow black add dup 1 gt { pop 1 } if 1 exch sub
     setrgbcolor
  } bind def
} ifelse

/RE { %def
  findfont begin
  currentdict dup length dict begin
    { %forall
      1 index /FID ne { def } { pop pop } ifelse
    } forall
    /FontName exch def dup length 0 ne { %if
      /Encoding Encoding 256 array copy def
      0 exch { %forall
        dup type /nametype eq { %ifelse
          Encoding 2 index 2 index put
          pop 1 add
        }{ %else
          exch pop
        } ifelse
      } forall
    } if pop
  currentdict dup end end
  /FontName get exch definefont pop
} bind def

/spacecount { %def
  0 exch
  ( ) { %loop
    search { %ifelse
      pop 3 -1 roll 1 add 3 1 roll
    }{ pop exit } ifelse
  } loop
} bind def

/WinAnsiEncoding [
  39/quotesingle 96/grave 130/quotesinglbase/florin/quotedblbase
  /ellipsis/dagger/daggerdbl/circumflex/perthousand
  /Scaron/guilsinglleft/OE 145/quoteleft/quoteright
  /quotedblleft/quotedblright/bullet/endash/emdash
  /tilde/trademark/scaron/guilsinglright/oe/dotlessi
  159/Ydieresis 164/currency 166/brokenbar 168/dieresis/copyright
  /ordfeminine 172/logicalnot 174/registered/macron/ring
  177/plusminus/twosuperior/threesuperior/acute/mu
  183/periodcentered/cedilla/onesuperior/ordmasculine
  188/onequarter/onehalf/threequarters 192/Agrave/Aacute
  /Acircumflex/Atilde/Adieresis/Aring/AE/Ccedilla
  /Egrave/Eacute/Ecircumflex/Edieresis/Igrave/Iacute
  /Icircumflex/Idieresis/Eth/Ntilde/Ograve/Oacute
  /Ocircumflex/Otilde/Odieresis/multiply/Oslash
  /Ugrave/Uacute/Ucircumflex/Udieresis/Yacute/Thorn
  /germandbls/agrave/aacute/acircumflex/atilde/adieresis
  /aring/ae/ccedilla/egrave/eacute/ecircumflex
  /edieresis/igrave/iacute/icircumflex/idieresis
  /eth/ntilde/ograve/oacute/ocircumflex/otilde
  /odieresis/divide/oslash/ugrave/uacute/ucircumflex
  /udieresis/yacute/thorn/ydieresis
] def

/patarray [
/leftdiagonal /rightdiagonal /crossdiagonal /horizontal
/vertical /crosshatch /fishscale /wave /brick
] def
/arrowtype 0 def
/fillC 0 def /fillM 0 def /fillY 0 def /fillK 0 def
/strokeC 0 def /strokeM 0 def /strokeY 0 def /strokeK 1 def
/pattern -1 def
/mat matrix def
/c /curveto load def
/C /curveto load def
/e { gsave concat 0 0 moveto } bind def
/F {
  pattern -1 eq { %ifelse
    fillC fillM fillY fillK setcmykcolor fill
  }{ %else
    gsave fillC fillM fillY fillK setcmykcolor fill grestore
    0 0 0 1 setcmykcolor
    patarray pattern get findfont patternfill
  } ifelse
} bind def
/f { closepath F } bind def
/K { /strokeK exch def /strokeY exch def
     /strokeM exch def /strokeC exch def } bind def
/k { /fillK exch def /fillY exch def
     /fillM exch def /fillC exch def } bind def
/L /lineto load def
/m /moveto load def
/n /newpath load def
/N /newpath load def
/S { strokeC strokeM strokeY strokeK setcmykcolor stroke } bind def
/s { closepath S } bind def
/Tx { fillC fillM fillY fillK setcmykcolor show
      0 leading neg translate 0 0 moveto } bind def
/t { %def
  fillC fillM fillY fillK setcmykcolor
  align dup 0 eq { %ifelse
    pop show
  }{ %else
    dup 1 eq { %ifelse
      pop dup stringwidth pop 2 div neg 0 rmoveto show
    }{ %else
      dup 2 eq { %ifelse
        pop dup stringwidth pop neg 0 rmoveto show
      }{ %else
        pop
        dup stringwidth pop jwidth exch sub
        1 index spacecount
        dup 0 eq { %ifelse
          pop pop show
        }{ %else
          div 0 8#040 4 -1 roll widthshow
        } ifelse
      } ifelse
    } ifelse
  } ifelse
  0 leading neg translate 0 0 moveto
} bind def
/T { grestore } bind def
/TX { pop } bind def
/tbx { pop exch pop sub /jwidth exch def } def
/u {} def
/U {} def
/w /setlinewidth load def
/d /setdash load def
/B { gsave F grestore S } bind def
/b { closepath B } bind def
/z { /align exch def pop /leading exch def exch findfont
     exch scalefont setfont } bind def
/Pat { /pattern exch def } bind def
/At { /arrowtype exch def } bind def
/Ln {
  mat currentmatrix pop
    concat
    /y1 exch def /x1 exch def /y2 exch def /x2 exch def
    dup 2 mod 1 eq { currentlinewidth x2 y2 x1 y1 arrowhead } if
    2 idiv 1 eq { currentlinewidth x1 y1 x2 y2 arrowhead } if
    x1 y1 moveto x2 y2 lineto
  mat setmatrix
} bind def
/Ar {
  mat currentmatrix pop
    concat translate scale 0 0 1 5 -2 roll arc
  mat setmatrix
} bind def
/Pi {
  mat currentmatrix pop
    concat translate scale
    0 0 moveto 0 0 1 5 -2 roll arc closepath
  mat setmatrix
} bind def
/Bx {
  mat currentmatrix pop
    concat /y1 exch def /x1 exch def /y2 exch def /x2 exch def
    x1 y1 moveto x1 y2 lineto x2 y2 lineto x2 y1 lineto
  mat setmatrix
} bind def
/Ov {
  mat currentmatrix pop
    concat translate scale 0 0 1 0 360 arc
  mat setmatrix
} bind def
end
%%EndResource
%%EndProlog
%%BeginSetup
%PDX g 18 18 0 0
%%IncludeFont: ComicSansMS
%%IncludeFont: ArialMT
PDXDict begin
%%EndSetup
%%Page: 1 1
%%BeginPageSetup
/_PDX_savepage save def

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/rightdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/leftdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  2 setlinewidth stroke
} bind
/horizontal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/vertical true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/crosshatch true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 30 7.5 lineto
  0 22.5 moveto 30 22.5 lineto
  7.5 0 moveto 7.5 7.5 lineto
  7.5 22.5 moveto 7.5 30 lineto
  22.5 7.5 moveto 22.5 22.5 lineto
  1 setlinewidth stroke
} bind
/brick true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  0.5 setlinewidth stroke
} bind
/crossdiagonal true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  1 setlinecap
  0 7.5 moveto 0 15 7.5 270 360 arc
  7.5 15 moveto 15 15 7.5 180 270 arc
  0 7.5 moveto 7.5 7.5 7.5 180 360 arc
  0.5 setlinewidth stroke
} bind
/fishscale true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  1 setlinecap 0.5 setlinewidth
  7.5 0 10.6 135 45 arcn
  22.5 15 10.6 225 315 arc
  stroke
  7.5 15 10.6 135 45 arcn
  22.5 30 10.6 225 315 arc
  stroke
} bind
/wave true definepattern pop

WinAnsiEncoding /_ComicSansMS /ComicSansMS RE
WinAnsiEncoding /_ArialMT /ArialMT RE

newpath 0 setlinecap 0 setlinejoin 10 setmiterlimit
1 setlinewidth [] 0 setdash
%%EndPageSetup
1 1 1 0 k
174.866 80.8629 344.953 199.241 [0.943 0.2997 -0.05172 0.7894 70.66 -71.22] Ov
f
1 1 1 0 k
174.866 80.8629 344.953 199.241 [0.943 0.2997 -0.05172 0.7894 70.66 -75.22] Ov
f
164.758 71.7658 345.668 199.241 [0.943 0.2997 -0.05172 0.7894 72.5 -71.93] Ov
0 0 0 0 k
f
432.916 159.367 224.39 215.368 [0.919 0.3942 -0.3942 0.919 136.6 -45.84] Bx
f
431.575 432.811 m
431.672 427.809 377.083 433.555 337.977 429.787 C
240.471 420.391 215.296 368.318 211.273 360.021 C
202.145 341.193 240.95 182.485 377.799 201.943 C
452.614 212.58 482.782 353.988 451.407 414.323 C
451.073 414.965 453.323 415.921 453.821 415.529 C
493.539 384.285 470.715 247.575 405.553 205.563 C
352.776 171.536 278.849 206.547 246.268 250.211 C
205.354 305.042 197.142 357.632 208.578 374.917 C
214.267 383.516 228.228 428.253 346.424 441.854 C
384.953 446.288 431.494 436.929 431.575 432.811 c
1 1 1 0 k
b
427.402 417.199 m
428.811 417.659 447.452 407.694 444.794 398.122 C
440.547 382.826 426.589 371.671 414.69 365.059 C
391.101 351.951 357.889 340.887 323.528 340.984 C
310.415 341.021 296.84 338.573 264.736 341.958 C
250.544 343.455 213.532 354.74 219.793 354.937 C
226.536 355.149 256.47 345.803 284.665 345.505 C
346.574 344.852 367.136 353.978 386.631 360.392 C
398.183 364.193 419.222 371.555 426.775 381.497 C
429.646 385.276 435.709 387.542 438.861 397.935 C
441.543 406.778 426.421 416.878 427.402 417.199 c
b
461.49 359.02 m
461.015 360.3 456.617 347.741 452.767 344.811 C
445.79 339.501 435.647 347.635 426.697 342.865 C
420.448 339.535 423.565 332.065 417.747 330.025 C
411.387 327.794 389.866 329.921 383.506 327.69 C
377.688 325.649 370.002 311.965 364.44 310.569 C
358.477 309.073 337.159 311.55 330.588 310.569 C
323.845 309.563 316.356 303.244 309.965 302.787 C
300.353 302.1 251.639 305.88 252.828 304.095 C
254.257 301.951 308.013 296.006 311.911 296.951 C
316.006 297.943 331.009 306.772 335.646 306.289 C
340.263 305.808 362.39 304.143 367.553 304.344 C
375.587 304.656 381.919 320.862 388.953 322.242 C
395.213 323.471 413.902 320.679 420.86 323.799 C
426.995 326.55 425.376 334.386 431.755 337.028 C
436.265 338.897 443.018 336.163 446.93 336.639 C
450.797 337.11 455.654 338.427 458.603 341.698 C
463.34 346.951 460.168 345.381 464.44 350.647 C
467.003 353.807 461.905 357.901 461.49 359.02 c
b
33.8883 31.5754 m
33.8883 767.665 L
124.391 767.665 L
100.257 675.955 L
126.804 575.799 L
105.084 498.57 L
119.564 368.246 L
95.4302 278.95 L
123.184 143.799 L
105.084 31.5754 L
33.8883 31.5754 L
b
0 0 0 0 k
/_ComicSansMS 24 24 0 0 z
[0 1.039 -1.154 0 80.43 88.32] e
650 -7.008 0 26.448 tbx
(C  O  M  P  L  I  M  E  N  T  A  R  Y      C  O  U  P  O  N) t
T
1 1 1 0 k
/_ArialMT 12 12 0 0 z
[1 0 0 1 299.4 57.23] e
99.373 -2.544 0 10.86 tbx
(With any purchase) t
T
[1 0 0 1 276.4 42.75] e
151.393 -2.544 0 10.86 tbx
(Good from 8:00--10:00 Daily) t
T
456.461 414.467 m
460.213 425.538 462.357 430.184 465.037 433.05 C
468.165 436.394 475.194 441.957 480.762 441.627 C
491.119 441.013 504.601 433.251 507.921 422.329 C
518.359 387.997 483.028 322.609 470.755 324.411 C
469.58 324.583 467.875 331.51 470.041 334.417 C
471.463 336.326 476.17 342.255 477.202 343.781 C
486.513 357.546 486.893 355.461 490.562 365.238 C
493.497 373.06 498.361 384.82 497.564 394.046 C
497.013 400.434 495.234 413.523 488.443 417.824 C
481.829 422.011 476.604 423.734 470.202 418.801 C
461.566 412.148 470.827 403.602 462.178 401.602 C
459.877 401.069 457.911 403.214 454.316 410.179 C
B
306.603 188.447 m
305.791 188.689 293.876 173.07 298.156 165.519 C
309.556 145.406 345.488 150.981 362.111 153.452 C
377.414 155.727 404.291 171.394 415.206 181.206 C
424.719 189.758 447.254 211.341 440.654 227.512 C
439.919 229.313 416.799 206.542 404.02 202.76 C
389.242 198.387 351.998 195.687 337.977 195.687 C
337.153 195.687 334.966 196.604 334.357 195.687 C
330.171 189.382 338.152 177.467 344.011 172.759 C
361.807 158.46 388.474 173.126 388.807 171.793 C
389.292 169.853 354.712 157.887 345.218 157.072 C
336.89 156.358 318.708 155.293 310.223 160.692 C
306.829 162.852 303.571 169.037 302.983 172.759 C
302.31 177.018 307.138 188.287 306.603 188.447 c
b
215.142 270.998 m
214.844 274.606 185.268 308.837 170.41 343.59 C
158.409 371.659 175.154 391.06 174.52 390.789 C
161.755 385.331 162.955 384.048 159.199 380.715 C
157.374 379.096 153.485 378.776 153.384 356.252 C
153.327 343.339 159.078 340.439 167.658 325.614 C
177.932 307.862 190.663 293.996 196.065 289.779 C
197.674 288.522 215.244 269.755 215.142 270.998 c
b
200.577 240.903 m
200.577 243.643 162.962 261.032 151.26 265.918 C
150.782 266.118 149.794 267.052 149.116 266.633 C
146.086 264.76 144.074 257.169 147.687 256.627 C
161.981 254.483 200.577 240.188 200.577 240.903 c
b
240.536 353.5 m
239.157 356.302 260.344 377.171 267.989 381.52 C
283.293 390.224 294.405 399.21 333.151 409.274 C
360.651 416.417 392.992 415.98 409.821 412.071 C
413.996 411.102 421.684 407.084 424.464 403.5 C
427.447 399.655 430.173 390.966 429.464 386 C
429.02 382.891 425.969 378.007 423.393 376.357 C
391.607 356 335.893 345.286 290.536 344.571 C
286.942 344.515 288.325 351.403 288.75 353.857 C
289.476 358.053 291.607 362.071 296.964 367.786 C
297.085 367.914 296.86 368.363 296.964 368.5 C
301.607 374.571 272.045 344.204 269.107 346.714 C
267.274 348.28 282.656 362.536 279.821 366 C
274.524 372.473 242.022 350.479 240.536 353.5 c
b
330.906 360.991 m
332.098 361.804 345.828 362.81 353.288 367.173 C
361.824 372.165 362.274 376.454 360.216 379.537 C
357.739 383.248 341.524 381.709 335.169 379.9 C
327.903 377.832 316.068 372.679 315.451 365.719 C
315.009 360.721 321.13 359.465 327.708 358.082 C
347.921 353.836 375.381 363.913 388.994 369.719 C
406.047 376.991 405.384 380.979 405.514 386.082 C
405.966 403.77 349.46 399.587 333.669 394.649 C
320.879 390.649 305.394 386.22 304.26 383.9 C
303.727 382.81 304.67 383.9 304.793 383.9 C
306.925 383.9 338.52 392.575 348.872 392.959 C
358.006 393.299 382.552 394.225 385.796 384.264 C
386.862 380.991 388.487 378.1 383.132 374.446 C
376.204 369.719 377.791 369.3 365.545 365.719 C
354.354 362.446 353.821 361.355 343.163 360.991 C
338.142 360.82 329.84 360.264 330.906 360.991 c
0 0 0 0 k
b
468.899 431.831 m
470.92 433.627 476.054 435.927 478.671 436.391 C
481.448 436.883 487.358 436.696 490.072 435.414 C
494.606 433.271 502.204 426.958 503.427 421.733 C
507.01 406.423 502.65 395.381 501.721 396 C
501.145 396.384 502.96 416.433 490.885 422.935 C
483.945 426.672 470.452 426.65 465.642 422.71 C
463.917 421.298 467.391 430.49 468.899 431.831 c
b
506.137 183.436 m
507.685 184.694 488.73 165.667 482.426 161.443 C
465.012 149.778 420.679 130.896 401.326 123.986 C
383.794 117.726 357.34 104.742 322.976 103.711 C
322.684 103.703 322.216 104.157 322.289 104.399 C
323.606 108.751 340.754 113.98 344.625 115.052 C
355.025 117.929 373.752 119.896 383.801 123.643 C
396.95 128.545 428.451 139.871 441.189 145.979 C
456.698 153.417 500.639 178.969 506.137 183.436 c
1 1 1 0 k
b
365.732 461.162 m
363.813 462.493 364.623 484.198 366.939 491.33 C
370.943 503.661 375.356 525.844 394.41 538.985 C
405.231 546.448 412.827 548.183 422.447 543.218 C
433.384 537.572 433.507 525.197 427.619 515.104 C
419.784 501.672 402.924 498.655 392.545 494.955 C
378.083 489.8 367.134 460.189 365.732 461.162 c
b
382 510.727 m
381.549 511.097 389.454 522.341 392.545 525.273 C
396.347 528.878 405.232 536.197 411.091 537.273 C
412.472 537.526 415.624 537.64 416.182 536.182 C
416.712 534.797 414.242 532.941 413.273 532.182 C
411.196 530.555 405.623 529.294 403.455 528.182 C
400.38 526.604 393.417 522.416 390.727 520.182 C
388.425 518.269 382.323 510.463 382 510.727 c
0 0 0 0 k
b
434.514 451.508 m
433.054 452.126 428.633 465.151 428.48 470.816 C
428.178 482.033 428.454 488.217 444.168 494.95 C
462.388 502.757 506.169 492.492 504.822 509.993 C
504.493 514.27 497.517 515.402 486.072 526.112 C
460.523 550.022 465.924 567.792 492.322 586.967 C
509.491 599.438 539.017 607.915 556.391 603.553 C
568.209 600.586 578.235 588.561 576.905 575.799 C
575.225 559.679 547.343 552.425 537.059 556.375 C
531.904 558.355 527.52 566.243 538.046 574.796 C
547.255 582.278 561.072 583.678 564.017 580.159 C
568.425 574.891 564.823 569.043 566.045 569.765 C
567.322 570.52 569.358 573.951 569.665 575.799 C
570.419 580.336 569.664 588.184 564.362 591.901 C
553.52 599.5 536.854 597.747 528.143 594.429 C
521.164 591.77 511.932 590.115 496.143 577.286 C
475.914 560.85 480.809 548.48 490.02 537.296 C
496.768 529.101 507.783 520.52 512.059 516.572 C
517.87 511.208 516.664 509.007 515.678 503.086 C
512.763 485.6 468.716 494.836 456.235 491.33 C
444.77 488.109 442.562 487.254 437.059 481.046 C
429.122 472.091 435.632 451.036 434.514 451.508 c
1 1 1 0 k
b
/_ComicSansMS 48 48 0 0 z
[0.8452 0.5345 -0.5345 0.8452 164.2 406.8] e
89.713 -14.016 0 52.896 tbx
(One) t
T
[0.6889 0.7249 -0.7249 0.6889 254.9 463.8] e
79.585 -14.016 0 52.896 tbx
(Cup) t
T
[0.8956 0.4447 -0.4447 0.8956 312.9 528.8] e
49.969 -14.016 0 52.896 tbx
(of) t
T
[0.9383 0.3457 -0.3457 0.9383 369.4 557.3] e
155.569 -14.016 0 52.896 tbx
(Coffee) t
T
512.667 252.109 m
512.964 252.464 519.036 250.679 526.667 245.109 C
531.417 239.859 530.917 230.359 528.667 225.859 C
521.917 212.359 507.761 203.43 500.667 197.609 C
490.402 189.186 464.451 171.866 452.667 165.859 C
427.167 152.859 414.667 148.359 399.667 142.609 C
429.417 161.109 455.667 176.109 480.417 191.859 C
478.167 196.359 477.167 196.609 474.917 200.359 C
480.167 199.859 486.167 199.859 493.417 199.859 C
489.667 202.859 486.917 203.859 482.667 206.859 C
489.167 207.359 493.667 206.359 500.167 206.359 C
496.917 210.109 496.167 210.359 493.417 213.609 C
499.917 213.859 504.167 213.859 511.167 214.359 C
506.417 217.609 503.917 219.109 498.917 222.609 C
505.667 223.109 508.917 222.609 516.417 222.859 C
511.167 225.359 507.667 226.609 502.917 229.359 C
508.917 232.859 512.417 233.859 518.167 236.859 C
510.167 236.109 507.917 235.859 501.917 235.859 C
505.167 241.109 508.84 247.536 512.667 252.109 c
b
/_ComicSansMS 24 36 0 1 z
[1 0 0 1 337.7 713] e
103.128 -79.008 -103.128 26.448 tbx
(Visit our Deli) t
(\r) TX
(and redeem) t
(\r) TX
(this coupon for) t
T
%%PageTrailer
_PDX_savepage restore
%%Trailer
end
showpage
%%EOF
